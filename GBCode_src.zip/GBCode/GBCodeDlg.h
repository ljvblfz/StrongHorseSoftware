// GBCodeDlg.h : header file
//

#if !defined(AFX_GBCODEDLG_H__B3C8F0D3_D364_42AE_9B48_E5C6B9649D96__INCLUDED_)
#define AFX_GBCODEDLG_H__B3C8F0D3_D364_42AE_9B48_E5C6B9649D96__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "AboutIcon.h"
#include "DragEdit.h"

/////////////////////////////////////////////////////////////////////////////
// CGBCodeDlg dialog

class CGBCodeDlg : public CDialog
{
// Construction
public:
	CGBCodeDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CGBCodeDlg)
	enum { IDD = IDD_GBCODE_DIALOG };
	CDragEdit	m_GragEdit;
	CString	m_strChnChar;
	BOOL	m_bTopMost;
	int		m_iList;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGBCodeDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
	CAboutIcon	m_AboutIcon;

	enum LIST_LIST
	{
		LIST_GB_ZONE1,
		LIST_GB_1,
		LIST_GB_2,
		LIST_CN_NUMB,
		LIST_CN_PY,
		LIST_JP_1,
		LIST_JP_2,
		LIST_GREEK,
		LIST_RUSS
	};

	void ShowCharInSeg(BYTE iSeg);
	void SetTopmost();

	// Generated message map functions
	//{{AFX_MSG(CGBCodeDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnBtnCheck();
	afx_msg void OnChangeEditSeg();
	afx_msg void OnCheckTopmost();
	afx_msg void OnSelchangeComboStyle();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GBCODEDLG_H__B3C8F0D3_D364_42AE_9B48_E5C6B9649D96__INCLUDED_)
